<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB; //libreria nos permite hacer insert
use Illuminate\Support\Str; //liberaria para funciones str


class TaskSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //inserta 10 tareas
        for($i =0; $i<=10; $i++)
        {
            DB::table('pokemon')->insert([
                'id' => '0',
                'Nombre' => Str::random(10),
                'Tipo' => Str::random(200),
                'Tamaño' => Str::random(200),
                'Peso' => Str::random(200),
            ]);
        }
    }
}
