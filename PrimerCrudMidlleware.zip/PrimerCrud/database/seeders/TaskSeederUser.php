<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB; //libreria nos permite hacer insert
use Illuminate\Support\Str; //liberaria para funciones str


class TaskSeederUser extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //inserta 10 tareas
     
        DB::table('usuario')->insert([
            'id' => 1,
            'Nombre' => 'AdminUser',
            'Contrasena' => '123',
            'Rol' => 'admin',
        ]);

        // Insertar usuario con rol "usuario"
        DB::table('usuario')->insert([
            'id' => 2,
            'Nombre' => 'Gabriel',
            'Contrasena' => '123',
            'Rol' => 'usuario',
        ]);
    }
}
