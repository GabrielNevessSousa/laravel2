<?php
session_start();

// Verificar si el usuario ya está autenticado y redirigir si es necesario
if (isset($_SESSION['usuario'])) {
    header("Location: dashboard.php");
    exit();
}

// Verificar si se ha enviado el formulario de inicio de sesión
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener las credenciales del formulario
    $inputUsuario = $_POST['usuario'];
    $inputContrasena = $_POST['contrasena'];

    // Configuración de la conexión a la base de datos
    $dsn = "localhost";
    $usuarioBD = "root";
    $contrasenaBD = "";
    $bd = "usuario";

    try {
        // Crear una conexión a la base de datos
        $conexion = new PDO($dsn, $usuarioBD, $contrasenaBD);

        // Configurar el modo de error para que PDO lance excepciones
        $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Consulta SQL para verificar las credenciales
        $consulta = $conexion->prepare("SELECT * FROM usuario WHERE nombre = :nombre AND contrasena = :contrasena");
        $consulta->bindParam(':nombre', $inputUsuario);
        $consulta->bindParam(':contrasena', $inputContrasena);
        $consulta->execute();

        // Obtener el resultado de la consulta
        $usuario = $consulta->fetch(PDO::FETCH_ASSOC);

        if ($usuario) {
            // Autenticación exitosa
            $_SESSION['usuario'] = [
                'nombre' => $usuario['nombre'],
                'rol' => $usuario['rol'],
            ];

            // Redirigir según el rol
            if ($usuario['rol'] === 'admin') {
                header("Location: dashboard_admin.php");
            } elseif ($usuario['rol'] === 'usuario') {
                header("Location: dashboard_usuario.php");
            } else {
                // Manejar otros roles según sea necesario
                header("Location: otro_dashboard.php");
            }
            
            exit();
        } else {
            $errorMensaje = "Credenciales incorrectas. Por favor, inténtalo de nuevo.";
        }
    } catch (PDOException $e) {
        echo "Error de conexión a la base de datos: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión</title>
</head>
<body>

<h2>Iniciar Sesión</h2>

<?php if (isset($errorMensaje)) : ?>
    <p style="color: red;"><?php echo $errorMensaje; ?></p>
<?php endif; ?>

<form method="post" action="">
    <label for="usuario">Usuario:</label>
    <input type="text" id="usuario" name="usuario" required>

    <br>

    <label for="contrasena">Contraseña:</label>
    <input type="password" id="contrasena" name="contrasena" required>

    <br>

    <button type="submit">Iniciar Sesión</button>
</form>

</body>
</html>
