

@extends('layout/template')

@section('contenido')

<a href="{{ url('pokemons/create') }}" class="btn btn-primary btn-sm">Nuevo Pokemon</a>


<table class="table table-hover">

    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Tipo</th>
            <th>Tamaño</th>
            <th>Peso</th>
            <th>Acciones</th>
        </tr>
    </thead>

    <tbody>
        @foreach($pokemons as $pokemon)
        <tr>
            <td>{{ $pokemon->id }}</td>
            <td>{{ $pokemon->Nombre }}</td>
            <td>{{ $pokemon->Tipo }}</td>
            <td>{{ $pokemon->Tamaño }}</td>
            <td>{{ $pokemon->Peso }}</td>
     <td>      <a href="{{ url('pokemons/' . $pokemon->id . '/edit') }}" class="btn btn-primary btn-sm">Editar Pokemon</a>

            <td>
                <form action="{{ url('pokemons/'.$pokemon->id)}}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button type="submit">Eliminar</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>

</table>

@endsection

