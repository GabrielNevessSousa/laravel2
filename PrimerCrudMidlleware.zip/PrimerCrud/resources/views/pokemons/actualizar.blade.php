

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <h1">Modificar Pokemon</h1>

                <div class="card-body">
                    
                <form action="{{ url('pokemons/' . $pokemon->id) }}" method="POST">
    @method("PUT")
    @csrf

    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="nombre" value="{{ $pokemon->id }}" required>


    <label for="tipo">Tipo:</label>
    <select id="tipo" name="tipo" required>
      <option value="fuego">Fuego</option>
      <option value="agua">Agua</option>
      <option value="planta">Planta</option>
      <!-- Agrega más opciones según tus necesidades -->

      <p>adiossssss</p>
    </select>

    <label for="tamaño">Tamaño:</label>
    <select id="tamaño" name="tamaño">
      <option value="grande">Grande</option>
      <option value="mediano">Mediano</option>
      <option value="pequeño">Pequeño</option>
    </select>

    <label for="peso">Peso:</label>
    <input type="text" id="peso" name="peso" required>
    <button type="submit">Guardar Pokémon</button>
  </form>
                </div>
            </div>
        </div>
    </div>
</div>
